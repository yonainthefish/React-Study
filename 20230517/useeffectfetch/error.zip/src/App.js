import NationList from "./components/NationList";

function App() {
  return (
    <div>
      <NationList/>
      
    </div>
  );
}
export default App;
