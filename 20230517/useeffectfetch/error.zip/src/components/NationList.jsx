import React, { useEffect, useState } from 'react'

export default function NationList() {

    const [nations, setNations] = useState([]);

    useEffect(() => {
        fetch("http://localhost:3000/nations")
            .then(response => {
                // http 상태코드가 200번때가 아닐 경우
                if (!response.ok) {
                    throw new Error("네트워크 응답에 문제가 있습니다.");
                }
                return response.json()
            })
            .then(json => setNations(json))
            .catch((error) => {
                console.error('데이터를 가져오는데 문제가 발생했습니다 : ', error);
            })
    }, [])

    console.log(nations);

    return (
        <div>NationList</div>
    )
}